import flet as ft

def main(page: ft.Page):
    page.title = "test-app"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # x = ft.Column([
    #     ft.ElevatedButton(text="test"),
    #     ft.FilledButton(text="test"),
    #     ft.TextButton(text="test"),
    #     ft.OutlinedButton(text="test"),
    #     ft.FloatingActionButton(text="test")
    # ])



    # x = ft.Column([ft.Text(value="ChatAPP", size=50, color=ft.colors.BLUE),ft.Text(value="User Name"), ft.TextField(), ft.Text(value="Password"), ft.TextField()], alignment=ft.MainAxisAlignment.CENTER)


    # page.add(ft.SafeArea(x))
    page.add(ft.ElevatedButton(text="test", on_click=lambda _: print("test")))
    # page.controls.append()

ft.app(target=main)
